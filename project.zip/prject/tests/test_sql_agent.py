from sql.database import create_database, insert_sample_data
from agents.sql_agent import run_sql_agent


def test_sql_agent():

    create_database()
    insert_sample_data()

    questions = [
        "Show all sales",
        "What is the total revenue?",
        "What is the average revenue?",
        "What is the highest revenue?",
        "What is the total revenue in 2025?"
    ]

    for question in questions:

        print("\n" + "=" * 50)
        print("QUESTION:", question)

        response = run_sql_agent(question)

        print("SQL:", response["sql"])
        print("RESULT:", response["result"])


if __name__ == "__main__":
    test_sql_agent()